# Manual Order Variation Picker for WooCommerce

Version: **1.0.0** — Release Candidate

Choose a variable product by its individual attributes when creating or editing a manual WooCommerce admin order. The plugin resolves a real WooCommerce variation and adds a standard order item. WooCommerce's original **Add product(s)** function remains available.

## Requirements

- WordPress 7.0 or later; tested on 7.0 and 7.1.3.
- WooCommerce 11.2.0 or later; tested on 11.2.0 and 11.2.1.
- PHP 8.3.6 or later. Native compatibility testing used PHP 8.3.6. PHP 8.4/8.5 have not received the full compatibility test suite.
- A working WooCommerce database. Native tests used MariaDB 10.11.14 / InnoDB; MySQL has not been separately tested.
- A modern browser supporting native HTML dialogs. Chromium 138 was tested.

The tested WordPress/WooCommerce pairs were 7.0/11.2.0 and 7.1.3/11.2.1, each with HPOS and Legacy storage. These are tested compatibility bounds, not a guarantee for every future release or third-party extension.

## Installation

1. Install and activate WooCommerce.
2. Go to **Plugins → Add New Plugin → Upload Plugin**.
3. Select the supplied ZIP, install it, and activate **Manual Order Variation Picker for WooCommerce**.
4. Test on a staging store before using it with live orders.

When updating an existing installation, replace the existing plugin when WordPress prompts you. Deactivating the plugin does not remove existing order items or their selected attributes.

## Usage

The picker uses English source labels and messages with WordPress translation support. Product names and attribute values remain as configured in your store.

1. Open **WooCommerce → Orders**, then create a new order or open an editable order.
2. Click **Select variation** below the order items. You do not need to click **Add item(s)** first.
3. Search using at least two characters from the product name or parent SKU, then select the product.
4. Choose a concrete value for every variation attribute and enter a whole-number quantity.
5. Check the resolved variation ID, unit price excluding tax, and any backorder indication.
6. Click **Add to order**, then **Close**.
7. Use WooCommerce's **Recalculate** action to update totals and taxes, then save the order.

Adding an item saves that item immediately through WooCommerce. Closing the picker does not undo the addition. If the request outcome is uncertain after a network error, reload and inspect the order before attempting another addition.

## HPOS and Legacy compatibility

The plugin declares HPOS compatibility. The complete admin workflow was tested with both HPOS and Legacy order storage, including saving and reopening orders, preserving attributes, recalculation, and the original WooCommerce product picker. No order-storage migration is required by this plugin.

## Known limitations

- Intended for published standard variable products and active, published, purchasable variations on editable admin orders.
- Search returns up to 20 variable parent products. Refine broad queries using the name or parent SKU.
- All attributes require a concrete selection, including attributes configured as ANY. The concrete selection is stored on the order item; no new variation is created.
- Overlapping ANY and specific variations follow WooCommerce's matching order. Verify the displayed variation ID.
- Quantity must be a whole number from 1 to 9999; WooCommerce's own restrictions also apply.
- Stock checks include existing outstanding quantities sharing the same stock-owning product. They do not reserve inventory or add cross-order concurrency locking.
- Backorders follow WooCommerce product settings. Use the original WooCommerce picker for special admin cases outside this plugin's scope.
- No dedicated compatibility is provided for swatches, bundles, composites, add-ons, subscription products, or external pricing extensions.
- No external service, licence activation server, automatic updater, or telemetry is included. Updates can be installed manually.

## Data

The plugin adds normal WooCommerce order items, selected variation attributes, and an internal `_movp_request_id` item meta value used to identify repeated add requests. The internal key is hidden in the order-item admin view and editor. Existing order data is retained when the plugin is deactivated or removed.

## Changelog

### 1.0.0

- First release candidate, based on the compatibility-tested 0.1.3 runtime.
- English default interface with literal WordPress text domains; later translations can use standard WordPress language files.
- Consistent version and tested minimum requirements.
- English user documentation and standard readme; customer package excludes development tests and internal validation reports.

## Licence

GPL-3.0-or-later. See `LICENSE`.
