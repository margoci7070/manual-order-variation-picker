<?php
/**
 * Plugin Name: Manual Order Variation Picker for WooCommerce
 * Description: Attribute-by-attribute variation selection for manual WooCommerce admin orders.
 * Version: 1.0.0
 * Requires at least: 7.0
 * Requires PHP: 8.3.6
 * Requires Plugins: woocommerce
 * WC requires at least: 11.2.0
 * WC tested up to: 11.2.1
 * Text Domain: manual-order-variation-picker
 * License: GPL-3.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-3.0.html
 */

defined( 'ABSPATH' ) || exit;

add_action( 'before_woocommerce_init', static function () {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
} );

final class MOVP_Plugin {
	const VERSION = '1.0.0';
	const DOMAIN  = 'manual-order-variation-picker';
	private static $validated = null;

	public static function boot() {
		if ( ! defined( 'WC_VERSION' ) || version_compare( WC_VERSION, '11.2', '<' ) ) {
			add_action( 'admin_notices', static function () {
				if ( current_user_can( 'activate_plugins' ) ) {
					echo '<div class="notice notice-warning"><p>' . esc_html__( 'Manual Order Variation Picker requires WooCommerce 11.2.0 or later.', 'manual-order-variation-picker' ) . '</p></div>';
				}
			} );
			return;
		}
		add_action( 'woocommerce_order_item_add_action_buttons', array( __CLASS__, 'button' ) );
		add_filter( 'woocommerce_hidden_order_itemmeta', static function ( $hidden_keys ) {
			$hidden_keys[] = '_movp_request_id';
			return $hidden_keys;
		} );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_footer', array( __CLASS__, 'dialog' ) );
		add_action( 'wp_ajax_movp_search', array( __CLASS__, 'search' ) );
		add_action( 'wp_ajax_movp_attributes', array( __CLASS__, 'attributes' ) );
		add_action( 'wp_ajax_movp_resolve', array( __CLASS__, 'resolve' ) );
		add_filter( 'woocommerce_ajax_add_order_item_validation', array( __CLASS__, 'validate_add' ), 20, 4 );
		add_filter( 'woocommerce_ajax_order_item', array( __CLASS__, 'save_selection' ), 20, 4 );
	}

	private static function is_order_screen() {
		$screen = get_current_screen();
		return $screen && in_array( $screen->id, array( 'shop_order', wc_get_page_screen_id( 'shop-order' ) ), true );
	}

	public static function assets() {
		if ( ! self::is_order_screen() || ! current_user_can( 'edit_shop_orders' ) ) {
			return;
		}
		wp_enqueue_style( 'movp', plugins_url( 'assets/picker.css', __FILE__ ), array(), self::VERSION );
		wp_enqueue_script( 'movp', plugins_url( 'assets/picker.js', __FILE__ ), array( 'jquery' ), self::VERSION, true );
		wp_localize_script( 'movp', 'MOVP', array(
			'url' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'movp' ),
			'orderNonce' => wp_create_nonce( 'order-item' ),
			'text' => array(
				'loading' => __( 'Loading…', 'manual-order-variation-picker' ),
				'choose' => __( 'Choose…', 'manual-order-variation-picker' ),
				'empty' => __( 'No products found.', 'manual-order-variation-picker' ),
				'error' => __( 'The request failed. Check the order, then try again.', 'manual-order-variation-picker' ),
				'added' => __( 'Variation added. Use the WooCommerce Recalculate button to update the order totals.', 'manual-order-variation-picker' ),
				'checking' => __( 'Checking variation…', 'manual-order-variation-picker' ),
				'selection' => __( 'Select all attributes and enter a quantity.', 'manual-order-variation-picker' ),
				'working' => __( 'Adding variation…', 'manual-order-variation-picker' ),
				'backorder' => __( 'Available on backorder.', 'manual-order-variation-picker' ),
				'sku' => __( 'SKU:', 'manual-order-variation-picker' ),
				'unitPrice' => __( 'Unit price excluding tax:', 'manual-order-variation-picker' ),
				'unknownOutcome' => __( 'The result of the add request is uncertain. Reload the order to check its items.', 'manual-order-variation-picker' ),
			),
		) );
	}

	public static function button( $order ) {
		if ( $order instanceof WC_Order && $order->is_editable() && current_user_can( 'edit_shop_order', $order->get_id() ) ) {
			echo '<button type="button" class="button movp-open" data-order-id="' . esc_attr( $order->get_id() ) . '">' . esc_html__( 'Select variation', 'manual-order-variation-picker' ) . '</button>';
		}
	}

	public static function dialog() {
		if ( ! self::is_order_screen() || ! current_user_can( 'edit_shop_orders' ) ) {
			return;
		}
		?>
		<dialog id="movp-dialog" aria-labelledby="movp-title">
			<form id="movp-form">
				<h2 id="movp-title"><?php esc_html_e( 'Select variation', 'manual-order-variation-picker' ); ?></h2>
				<label for="movp-search"><?php esc_html_e( 'Search products by name or SKU', 'manual-order-variation-picker' ); ?></label>
				<input id="movp-search" type="search" autocomplete="off" />
				<div id="movp-results" aria-live="polite"></div>
				<p id="movp-product"></p>
				<div id="movp-attributes"></div>
				<label for="movp-quantity"><?php esc_html_e( 'Quantity', 'manual-order-variation-picker' ); ?></label>
				<input id="movp-quantity" type="number" min="1" step="1" value="1" required />
				<p id="movp-status" role="status" aria-live="polite"></p>
				<div class="movp-actions">
					<button type="button" class="button" id="movp-close"><?php esc_html_e( 'Close', 'manual-order-variation-picker' ); ?></button>
					<button type="submit" class="button button-primary" id="movp-add" disabled><?php esc_html_e( 'Add to order', 'manual-order-variation-picker' ); ?></button>
				</div>
			</form>
		</dialog>
		<?php
	}

	private static function input( $key, $default = '' ) {
		// All AJAX reads are authenticated in authorize() / validate_add().
		return isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : $default; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	private static function order( $id ) {
		$order = wc_get_order( absint( $id ) );
		if ( ! $order instanceof WC_Order || ! current_user_can( 'edit_shop_orders' ) || ! current_user_can( 'edit_shop_order', $order->get_id() ) || ! $order->is_editable() ) {
			throw new Exception( __( 'This order cannot be edited, or you do not have permission to edit it.', 'manual-order-variation-picker' ) );
		}
		return $order;
	}

	private static function authorize() {
		check_ajax_referer( 'movp', 'nonce' );
		return self::order( self::input( 'order_id' ) );
	}

	private static function parent_product( $id ) {
		$product = wc_get_product( absint( $id ) );
		if ( ! $product instanceof WC_Product_Variable || 'variable' !== $product->get_type() || 'publish' !== $product->get_status() ) {
			throw new Exception( __( 'Select a published standard variable product.', 'manual-order-variation-picker' ) );
		}
		return $product;
	}

	public static function search() {
		try {
			self::authorize();
			$term = self::input( 'term' );
			if ( ! is_string( $term ) || strlen( trim( $term ) ) < 2 ) {
				wp_send_json_success( array() );
			}
			$term = sanitize_text_field( $term );
			// Query only variable parents, so simple products cannot crowd them out.
			$args = array( 'type' => 'variable', 'status' => 'publish', 'limit' => 20, 'return' => 'ids', 'orderby' => 'title', 'order' => 'ASC' );
			$ids = array_unique( array_merge(
				wc_get_products( array_merge( $args, array( 's' => $term ) ) ),
				wc_get_products( array_merge( $args, array( 'sku' => $term ) ) )
			) );
			$results = array();
			foreach ( $ids as $id ) {
				$product = wc_get_product( $id );
				if ( $product instanceof WC_Product_Variable && 'variable' === $product->get_type() && 'publish' === $product->get_status() ) {
					$results[] = array( 'id' => $product->get_id(), 'name' => $product->get_name(), 'sku' => $product->get_sku() );
				}
				if ( count( $results ) >= 20 ) {
					break;
				}
			}
			wp_send_json_success( $results );
		} catch ( Exception $e ) {
			wp_send_json_error( array( 'error' => $e->getMessage() ), 400 );
		}
	}

	public static function attributes() {
		try {
			self::authorize();
			$product = self::parent_product( self::input( 'product_id' ) );
			$fields = array();
			foreach ( $product->get_variation_attributes() as $name => $values ) {
				$options = array();
				foreach ( $values as $value ) {
					$label = $value;
					if ( taxonomy_exists( $name ) ) {
						$term = get_term_by( 'slug', $value, $name );
						$label = $term ? $term->name : $value;
					}
					$options[] = array( 'value' => (string) $value, 'label' => (string) $label );
				}
				$fields[] = array( 'key' => wc_variation_attribute_name( $name ), 'label' => wc_attribute_label( $name, $product ), 'options' => $options );
			}
			wp_send_json_success( array( 'id' => $product->get_id(), 'name' => $product->get_name(), 'fields' => $fields ) );
		} catch ( Exception $e ) {
			wp_send_json_error( array( 'error' => $e->getMessage() ), 400 );
		}
	}

	/** Match with core precedence, but require concrete, allowed values even for ANY. */
	public static function match( $parent_id, $raw_attributes ) {
		$parent = self::parent_product( $parent_id );
		$allowed = $parent->get_variation_attributes();
		if ( ! is_array( $raw_attributes ) || ! $allowed || count( $raw_attributes ) !== count( $allowed ) ) {
			throw new Exception( __( 'Select a value for every attribute.', 'manual-order-variation-picker' ) );
		}
		$attributes = array();
		foreach ( $allowed as $name => $values ) {
			$key = wc_variation_attribute_name( $name );
			$value = isset( $raw_attributes[ $key ] ) ? $raw_attributes[ $key ] : null;
			if ( ! is_string( $value ) || '' === $value || ! in_array( $value, array_map( 'strval', $values ), true ) ) {
				throw new Exception( __( 'An attribute value is missing or is not allowed.', 'manual-order-variation-picker' ) );
			}
			$attributes[ $key ] = $value;
		}
		$id = WC_Data_Store::load( 'product' )->find_matching_product_variation( $parent, $attributes );
		$variation = $id ? wc_get_product( $id ) : false;
		if ( ! $variation instanceof WC_Product_Variation || $variation->get_parent_id() !== $parent->get_id() ) {
			throw new Exception( __( 'No variation matches this attribute combination.', 'manual-order-variation-picker' ) );
		}
		return array( $variation, $attributes );
	}

	/** Check outstanding stock demand and return whether it requires backordering. */
	public static function availability( $variation, $order, $quantity ) {
		if ( ! is_scalar( $quantity ) || ! is_numeric( $quantity ) || ! is_finite( (float) $quantity ) || (float) $quantity < 1 || floor( (float) $quantity ) !== (float) $quantity || (float) $quantity > 9999 ) {
			throw new Exception( __( 'Quantity must be a whole number between 1 and 9999.', 'manual-order-variation-picker' ) );
		}
		$quantity = (int) $quantity;
		if ( 'publish' !== $variation->get_status() || ! $variation->is_purchasable() || ! $variation->variation_is_active() ) {
			throw new Exception( __( 'This variation is currently unavailable for purchase.', 'manual-order-variation-picker' ) );
		}
		$stock_id = $variation->get_stock_managed_by_id();
		$outstanding = 0;
		$same_variation = 0;
		// Core may have loaded these items before saving the edits sent with an add.
		// Read persisted items through the active data store, not that object's item cache.
		foreach ( $order->get_data_store()->read_items( $order, 'line_item' ) as $item ) {
			$product = $item->get_product();
			if ( ! $product ) {
				continue;
			}
			if ( $product->get_id() === $variation->get_id() ) {
				$same_variation += $item->get_quantity();
			}
			if ( $product->get_stock_managed_by_id() === $stock_id ) {
				$outstanding += max( 0, $item->get_quantity() - (float) $item->get_meta( '_reduced_stock', true ) );
			}
		}
		if ( $variation->is_sold_individually() && ( $quantity > 1 || $same_variation > 0 ) ) {
			throw new Exception( __( 'Only one unit of this variation can be added per order.', 'manual-order-variation-picker' ) );
		}
		if ( ! $variation->is_in_stock() || ! $variation->has_enough_stock( $quantity + $outstanding ) ) {
			throw new Exception( __( 'There is not enough stock for this quantity.', 'manual-order-variation-picker' ) );
		}
		return $variation->is_on_backorder( $quantity + $outstanding );
	}

	public static function resolve() {
		try {
			$order = self::authorize();
			list( $variation ) = self::match( self::input( 'product_id' ), self::input( 'attributes', array() ) );
			$backorder = self::availability( $variation, $order, self::input( 'quantity', 1 ) );
			wp_send_json_success( array(
				'id' => $variation->get_id(), 'name' => $variation->get_name(), 'sku' => $variation->get_sku(),
				'price' => html_entity_decode( wp_strip_all_tags( wc_price( wc_get_price_excluding_tax( $variation, array( 'order' => $order ) ), array( 'currency' => $order->get_currency() ) ) ), ENT_QUOTES, 'UTF-8' ),
				'backorder' => $backorder,
			) );
		} catch ( Exception $e ) {
			wp_send_json_error( array( 'error' => $e->getMessage() ), 400 );
		}
	}

	/** Runs only for our marked requests; normal Add product(s) is untouched. */
	public static function validate_add( $errors, $product, $order, $quantity ) {
		if ( ! isset( $_POST['movp'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return $errors;
		}
		self::$validated = null;
		try {
			$payload = self::input( 'movp' );
			if ( ! is_array( $payload ) || ! isset( $payload['nonce'] ) || ! is_string( $payload['nonce'] ) || ! wp_verify_nonce( $payload['nonce'], 'movp' ) ) {
				throw new Exception( __( 'The security token is invalid. Reload the page.', 'manual-order-variation-picker' ) );
			}
			self::order( $order->get_id() );
			$data = self::input( 'data', array() );
			$request_id = isset( $payload['request_id'] ) && is_string( $payload['request_id'] ) ? $payload['request_id'] : '';
			if ( ! is_array( $data ) || count( $data ) !== 1 || ! preg_match( '/^[a-zA-Z0-9-]{16,80}$/D', $request_id ) ) {
				throw new Exception( __( 'The add request is invalid.', 'manual-order-variation-picker' ) );
			}
			foreach ( $order->get_items() as $item ) {
				if ( $request_id === $item->get_meta( '_movp_request_id', true ) ) {
					throw new Exception( __( 'This request has already been processed. Check the order before adding another item.', 'manual-order-variation-picker' ) );
				}
			}
			list( $variation, $attributes ) = self::match( $payload['product_id'] ?? 0, $payload['attributes'] ?? array() );
			if ( $variation->get_id() !== $product->get_id() ) {
				throw new Exception( __( 'The selected variation has changed. Select it again.', 'manual-order-variation-picker' ) );
			}
			self::availability( $variation, $order, $quantity );
			if ( ! $errors->get_error_code() ) {
				self::$validated = array( 'id' => $variation->get_id(), 'order_id' => $order->get_id(), 'attributes' => $attributes, 'request_id' => $request_id );
			}
		} catch ( Exception $e ) {
			$errors->add( 'movp_invalid', $e->getMessage() );
		}
		return $errors;
	}

	public static function save_selection( $item, $item_id, $order, $product ) {
		$context = self::$validated;
		if ( $context && $context['id'] === $product->get_id() && $context['order_id'] === $order->get_id() ) {
			$item->set_variation( $context['attributes'] );
			$item->add_meta_data( '_movp_request_id', $context['request_id'], true );
			$item->save();
			self::$validated = null;
		}
		return $item;
	}
}

add_action( 'plugins_loaded', array( 'MOVP_Plugin', 'boot' ) );
