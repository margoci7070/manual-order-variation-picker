=== Manual Order Variation Picker for WooCommerce ===
Tags: woocommerce, variations, orders, administration
Requires at least: 7.0
Tested up to: 7.1.3
Requires PHP: 8.3.6
Requires Plugins: woocommerce
WC requires at least: 11.2.0
WC tested up to: 11.2.1
Stable tag: 1.0.0
License: GPL-3.0-or-later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Select variable-product attributes in manual WooCommerce admin orders and add the matching real variation as a standard order item.

== Description ==

Version 1.0.0 is the first release candidate of Manual Order Variation Picker for WooCommerce.

Use a separate picker to search variable products, choose each variation attribute, and add the real WooCommerce variation to an editable admin order. The original WooCommerce Add product(s) picker remains available.

The picker preserves concrete choices for ANY attributes, validates stock and purchasability on the server, and indicates permitted backorders using the order's outstanding quantity. It supports HPOS and Legacy order storage.

The picker uses English source labels and messages with WordPress translation support. Product names and attribute values remain as configured in your store.

= Requirements and tested compatibility =

* WordPress 7.0 or later; tested on 7.0 and 7.1.3.
* WooCommerce 11.2.0 or later; tested on 11.2.0 and 11.2.1.
* PHP 8.3.6 or later; native compatibility tests used PHP 8.3.6.
* Native database tests used MariaDB 10.11.14 / InnoDB; MySQL was not separately tested.
* A modern browser with native HTML dialog support; Chromium 138 was tested.

The WordPress/WooCommerce pairs 7.0/11.2.0 and 7.1.3/11.2.1 passed with both HPOS and Legacy storage. Full compatibility testing has not been completed for PHP 8.4/8.5 or all future releases.

= Limitations =

* Published standard variable products and purchasable variations only; editable admin orders only.
* Search returns up to 20 variable parent products. Use a product name or parent SKU.
* Every attribute requires a concrete value, including ANY attributes. WooCommerce determines matching precedence.
* Whole-number quantities from 1 to 9999; WooCommerce restrictions still apply.
* Stock checks do not reserve inventory or introduce cross-order stock locking.
* No dedicated swatch, bundle, composite, add-on, subscription-product or external pricing integration.
* No licence activation service, automatic updater or telemetry is included; updates are installed manually.

== Installation ==

1. Install and activate WooCommerce.
2. Open Plugins > Add New Plugin > Upload Plugin and select the supplied ZIP.
3. Install and activate Manual Order Variation Picker for WooCommerce.
4. Verify the workflow on a staging store before using live orders.

== Usage ==

1. Open WooCommerce > Orders and create or open an editable order.
2. Click "Select variation" below the order items.
3. Search with at least two characters and select a variable product.
4. Select all attribute values and enter a whole-number quantity.
5. Review the variation ID, unit price excluding tax and backorder indication.
6. Click "Add to order", then "Close".
7. Use WooCommerce Recalculate and save the order.

Adding an item saves it immediately. Closing the picker does not undo it. After an uncertain network outcome, reload the order and inspect its items before retrying.

== Frequently Asked Questions ==

= Does this replace WooCommerce's existing product picker? =

No. The original Add product(s) workflow remains available.

= Does it create new variations? =

No. It adds a real WooCommerce variation and preserves the selected concrete attributes on the order item, including ANY selections.

= Does it support HPOS and Legacy? =

Yes. Both storage modes passed the manual-order workflow in the tested environments above.

= Where is the full user guide? =

See README.md in this package.

= What data remains when the plugin is removed? =

Normal order items, selected attributes and the internal _movp_request_id item meta remain with the WooCommerce order. The internal key is hidden in the order-item admin view and editor.

== Changelog ==

= 1.0.0 =
* First release candidate based on the compatibility-tested 0.1.3 runtime.
* English default interface with literal WordPress text domains.
* Updated version and tested minimum requirements.
* English documentation and a customer package without development tests or internal validation reports.

== Upgrade Notice ==

= 1.0.0 =
Requires PHP 8.3.6, WordPress 7.0 and WooCommerce 11.2.0 or later. Test the update on staging before using live orders.
