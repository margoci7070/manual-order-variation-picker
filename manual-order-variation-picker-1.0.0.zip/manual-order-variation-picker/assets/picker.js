/* global MOVP, jQuery */
(function ($) {
	'use strict';
	const dialog = document.getElementById('movp-dialog');
	if (!dialog) return;
	const form = document.getElementById('movp-form');
	const search = document.getElementById('movp-search');
	const results = document.getElementById('movp-results');
	const fields = document.getElementById('movp-attributes');
	const productName = document.getElementById('movp-product');
	const quantity = document.getElementById('movp-quantity');
	const status = document.getElementById('movp-status');
	const add = document.getElementById('movp-add');
	const close = document.getElementById('movp-close');
	let orderId = 0;
	let productId = 0;
	let variationId = 0;
	let busy = false;
	let uncertain = false;
	let searchTimer;
	let resolveTimer;
	let generation = 0;
	let searchGeneration = 0;
	let opener;

	function message(text, error = false) {
		status.textContent = text;
		status.classList.toggle('movp-error', error);
	}
	function failure(xhr) {
		return xhr.responseJSON?.data?.error || MOVP.text.error;
	}
	function request(action, data) {
		return $.ajax({ url: MOVP.url, method: 'POST', dataType: 'json', data: { action, nonce: MOVP.nonce, order_id: orderId, ...data } });
	}
	function selection() {
		const attributes = {};
		fields.querySelectorAll('select').forEach(select => { attributes[select.name] = select.value; });
		return attributes;
	}
	function resetSelection() {
		generation++;
		clearTimeout(resolveTimer);
		variationId = 0;
		add.disabled = true;
	}
	function checkSelection() {
		resetSelection();
		const attributes = selection();
		if (!productId || !Object.keys(attributes).length || Object.values(attributes).some(value => !value) || !quantity.checkValidity()) {
			message(MOVP.text.selection);
			return;
		}
		const current = generation;
		message(MOVP.text.checking);
		resolveTimer = setTimeout(() => {
			request('movp_resolve', { product_id: productId, attributes, quantity: quantity.value }).done(response => {
				if (current !== generation || !dialog.open) return;
				if (!response.success) { message(response.data?.error || MOVP.text.error, true); return; }
				variationId = response.data.id;
				const info = response.data;
				message(`${info.name} · #${info.id}${info.sku ? ' · ' + MOVP.text.sku + ' ' + info.sku : ''}\n${MOVP.text.unitPrice} ${info.price}${info.backorder ? ' · ' + MOVP.text.backorder : ''}`);
				add.disabled = false;
			}).fail(xhr => { if (current === generation && dialog.open) message(failure(xhr), true); });
		}, 200);
	}
	function chooseProduct(id) {
		resetSelection();
		const current = generation;
		productId = 0;
		fields.replaceChildren();
		productName.textContent = '';
		results.replaceChildren();
		searchGeneration++;
		message(MOVP.text.loading);
		request('movp_attributes', { product_id: id }).done(response => {
			if (current !== generation || !dialog.open) return;
			if (!response.success) { message(response.data?.error || MOVP.text.error, true); return; }
			productId = response.data.id;
			productName.textContent = response.data.name;
			response.data.fields.forEach((field, index) => {
				const label = document.createElement('label');
				const select = document.createElement('select');
				select.id = `movp-attribute-${index}`;
				select.name = field.key;
				select.required = true;
				label.htmlFor = select.id;
				label.textContent = field.label;
				select.add(new Option(MOVP.text.choose, ''));
				field.options.forEach(option => select.add(new Option(option.label, option.value)));
				fields.append(label, select);
			});
			message(MOVP.text.selection);
			fields.querySelector('select')?.focus();
		}).fail(xhr => { if (current === generation && dialog.open) message(failure(xhr), true); });
	}
	$(document).on('click', '.movp-open', function () {
		if (busy || uncertain) return;
		opener = this;
		orderId = Number(this.dataset.orderId);
		productId = 0;
		resetSelection();
		searchGeneration++;
		search.value = '';
		quantity.value = '1';
		fields.replaceChildren();
		results.replaceChildren();
		productName.textContent = '';
		message('');
		dialog.showModal();
		search.focus();
	});
	search.addEventListener('input', () => {
		clearTimeout(searchTimer);
		resetSelection();
		productId = 0;
		fields.replaceChildren();
		productName.textContent = '';
		message('');
		const current = ++searchGeneration;
		results.replaceChildren();
		const term = search.value.trim();
		if (term.length < 2) return;
		searchTimer = setTimeout(() => {
			request('movp_search', { term }).done(response => {
				if (current !== searchGeneration || !dialog.open) return;
				results.replaceChildren();
				if (!response.success) { message(response.data?.error || MOVP.text.error, true); return; }
				if (!response.data.length) results.textContent = MOVP.text.empty;
				response.data.forEach(product => {
					const button = document.createElement('button');
					button.type = 'button';
					button.className = 'button';
					button.textContent = `${product.name} · #${product.id}${product.sku ? ' · ' + product.sku : ''}`;
					button.addEventListener('click', () => chooseProduct(product.id));
					results.append(button);
				});
			}).fail(xhr => { if (current === searchGeneration && dialog.open) message(failure(xhr), true); });
		}, 250);
	});
	fields.addEventListener('change', checkSelection);
	quantity.addEventListener('input', checkSelection);
	close.addEventListener('click', () => { if (!busy) dialog.close(); });
	dialog.addEventListener('cancel', event => { if (busy) event.preventDefault(); });
	dialog.addEventListener('close', () => {
		resetSelection();
		searchGeneration++;
		clearTimeout(searchTimer);
		if (opener?.isConnected) opener.focus();
	});
	form.addEventListener('submit', event => {
		event.preventDefault();
		if (busy || uncertain || !variationId || add.disabled || !form.reportValidity()) return;
		busy = true;
		form.querySelectorAll('input, select, button').forEach(element => { element.disabled = true; });
		message(MOVP.text.working);
		const data = {
			action: 'woocommerce_add_order_item',
			order_id: orderId,
			security: MOVP.orderNonce,
			data: [{ id: variationId, qty: quantity.value }],
			movp: {
				nonce: MOVP.nonce,
				product_id: productId,
				attributes: selection(),
				request_id: window.crypto?.randomUUID ? window.crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}-movp`
			}
		};
		// Preserve unsaved item edits exactly as core's own add-items request does.
		// Only the order-items panel is read; the core Add products modal is never altered.
		if ($('button.cancel-action').attr('data-reload') === 'true') {
			data.items = $('table.woocommerce_order_items :input[name], .wc-order-totals-items :input[name]').serialize();
		}
		$.ajax({ url: MOVP.url, method: 'POST', dataType: 'json', data }).done(response => {
			if (!response.success || typeof response.data?.html !== 'string') {
				message(response.data?.error || MOVP.text.error, true);
				return;
			}
			// Use the fragment returned by Woo's own endpoint, then its reload event.
			$('#woocommerce-order-items > .inside').html(response.data.html);
			const notes = document.querySelector('#woocommerce-order-notes ul.order_notes');
			if (notes && typeof response.data.notes_html === 'string') notes.outerHTML = response.data.notes_html;
			$('#woocommerce-order-items').trigger('wc_order_items_reloaded');
			variationId = 0;
			message(MOVP.text.added);
		}).fail(xhr => {
			// The request may have committed before the connection failed. Require a reload
			// instead of offering a retry that could accidentally add a second line.
			uncertain = true;
			message(`${failure(xhr)}\n${MOVP.text.unknownOutcome}`, true);
		}).always(() => {
			busy = false;
			form.querySelectorAll('input, select, button').forEach(element => { element.disabled = false; });
			add.disabled = true;
		});
	});
})(jQuery);
